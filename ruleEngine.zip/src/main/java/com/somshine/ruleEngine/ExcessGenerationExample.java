package com.somshine.ruleEngine;

import com.somshine.ruleEngine.model.Applicant;
import com.somshine.ruleEngine.model.LoanApplication;
import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieRuntimeFactory;
import org.kie.dmn.api.core.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExcessGenerationExample {

    private static final Logger logger = LoggerFactory.getLogger(ExcessGenerationExample.class);

    public static void main(String[] args) {

        KieServices kieServices = KieServices.Factory.get();
        KieContainer kieContainer = kieServices.getKieClasspathContainer();

        logger.info("-----> Now we execute DMN <-----");

        DMNRuntime dmnRuntime = KieRuntimeFactory.of(kieContainer.getKieBase()).get(DMNRuntime.class);

        String namespace = "https://kie.apache.org/dmn/_C41BAECE-8708-45EB-A2EA-D0A85755091A";
        String modelName = "can-generation";

        DMNModel dmnModel = dmnRuntime.getModel(namespace, modelName);

        DMNContext dmnContext = dmnRuntime.newContext();
        dmnContext.set("value", 110);
        DMNResult dmnResult = dmnRuntime.evaluateAll(dmnModel, dmnContext);

        for (DMNDecisionResult dr : dmnResult.getDecisionResults()) {
            logger.info(
                    "Decision: '" + dr.getDecisionName() + "', " +
                            "Result: " + dr.getResult());
        }
    }
}
