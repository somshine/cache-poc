package com.somshine.ruleEngine;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieRuntimeFactory;
import org.kie.dmn.api.core.*;
import org.kie.dmn.core.api.DMNFactory;
import org.kie.internal.io.ResourceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class VoterRunner {
    private static final Logger logger = LoggerFactory.getLogger(VoterRunner.class);

    public static void main(String[] args) {
        KieServices kieServices = KieServices.Factory.get();
        KieContainer kieContainer = kieServices.getKieClasspathContainer();

        logger.info("-----> Now we execute DMN <-----");

        DMNRuntime dmnRuntime = KieRuntimeFactory.of(kieContainer.getKieBase()).get(DMNRuntime.class);

        String namespace = "https://kie.apache.org/dmn/_1EE130C0-4099-46E7-A735-B19F4F149049";
        String modelName = "voter";

        DMNModel dmnModel = dmnRuntime.getModel(namespace, modelName);

        DMNContext dmnContext = dmnRuntime.newContext();
        dmnContext.set("age", 20);
        dmnContext.set("havingIdentity", true);
        DMNResult dmnResult = dmnRuntime.evaluateAll(dmnModel, dmnContext);

        logger.info("-----> DMN Result <----- : {}", dmnResult.getDecisionResultByName("canVote"));

        for (DMNDecisionResult dr : dmnResult.getDecisionResults()) {
            logger.info(
                    "Decision: '" + dr.getDecisionName() + "', " +
                            "Result: " + dr.getResult());
        }
    }
}

