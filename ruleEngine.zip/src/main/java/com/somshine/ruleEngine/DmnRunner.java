package com.somshine.ruleEngine;

import org.kie.api.KieServices;
import org.kie.api.builder.*;
import org.kie.api.runtime.KieContainer;
import org.kie.dmn.api.core.*;
import org.kie.dmn.core.api.DMNFactory;
import org.kie.internal.io.ResourceFactory;

import java.util.List;

public class DmnRunner {
    public static void main(String[] args) {
        // 1) Build a KIE base with your DMN on the classpath or from file
        KieServices ks = KieServices.Factory.get();
        KieFileSystem kfs = ks.newKieFileSystem();

        // If the DMN is in src/main/resources:
        kfs.write(ResourceFactory.newClassPathResource("excess-generation.dmn"));

        // Or from an absolute path:
        // kfs.write(ResourceFactory.newFileResource("D:/path/to/excess-generation.dmn"));

        KieBuilder kb = ks.newKieBuilder(kfs).buildAll();
        if (kb.getResults().hasMessages(Message.Level.ERROR)) {
            kb.getResults().getMessages(Message.Level.ERROR)
                    .forEach(m -> System.err.println("Build error: " + m));
            throw new IllegalStateException("KIE build failed");
        }

        KieContainer kc = ks.newKieContainer(ks.getRepository().getDefaultReleaseId());

        // 2) Obtain DMNRuntime
        DMNRuntime dmnRuntime = kc.newKieSession().getKieRuntime(DMNRuntime.class);

        // 3) DEBUG: list all models that actually loaded
        List<DMNModel> models = dmnRuntime.getModels();
        System.out.println("Loaded DMN models:");
        models.forEach(m -> System.out.println(" - " + m.getName() + " @ " + m.getNamespace()));

        String namespace = "https://kiegroup.org/dmn/_DA8EB2C5-C3D3-491E-A070-E23536B85A91";
        String modelName = "excess-generation";

        DMNModel model = dmnRuntime.getModel(namespace, modelName);
        if (model == null || model.hasErrors()) {
            throw new IllegalStateException("Model not loaded or has errors.");
        }

        DMNContext ctx = DMNFactory.newContext();
        ctx.set("utilization", java.math.BigDecimal.valueOf(101)); // >100 => true

        DMNResult result = dmnRuntime.evaluateAll(model, ctx);

        result.getMessages().forEach(System.out::println);
        result.getDecisionResults().forEach(dr ->
                System.out.println(dr.getDecisionName()+": "+dr.getEvaluationStatus()+" => "+dr.getResult()));

        DMNDecisionResult dr = result.getDecisionResultByName("canGenerateExcess");
        if (dr == null) throw new IllegalStateException("Decision name mismatch.");
        System.out.println("canGenerateExcess = " + dr.getResult()); // expect: true
    }
}

