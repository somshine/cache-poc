Project Creation:
https://start.spring.io/#!type=maven-project&language=java&platformVersion=3.5.5&packaging=jar&jvmVersion=21&groupId=com.somshine&artifactId=ruleEngine&name=ruleEngine&description=Demo%20project%20for%20Spring%20Boot&packageName=com.somshine.ruleEngine&dependencies=devtools,lombok,web,batch


